﻿using Thiagarajan.RPGCore;
namespace Thiagarajan.RoleplayingGameInterfaces
{
    public interface ICombat
    {
        void AutoBattle();
    }
}